package com.storylens.app

import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

class TranslationEngine {
    private var translator: Translator? = null

    fun translate(text: String, from: AppLanguage, to: AppLanguage): Task<String> {
        val clean = text.trim()
        if (clean.isBlank()) return Tasks.forException(IllegalArgumentException("번역할 글이 없어요"))
        if (from == to) return Tasks.forResult(clean)

        translator?.close()
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(from.mlCode)
            .setTargetLanguage(to.mlCode)
            .build()

        val client = Translation.getClient(options)
        translator = client
        val conditions = DownloadConditions.Builder().build()

        // First use may download an on-device model. INTERNET permission is required.
        return client.downloadModelIfNeeded(conditions)
            .continueWithTask { downloadTask ->
                if (!downloadTask.isSuccessful) {
                    Tasks.forException(
                        downloadTask.exception
                            ?: IllegalStateException("번역 언어 파일을 내려받지 못했어요. 인터넷을 확인하고 다시 눌러주세요.")
                    )
                } else {
                    client.translate(clean)
                }
            }
            .continueWithTask { task ->
                if (!task.isSuccessful) {
                    Tasks.forException(task.exception ?: IllegalStateException("번역에 실패했어요"))
                } else {
                    val result = task.result?.trim().orEmpty()
                    if (result.isBlank()) {
                        Tasks.forException(IllegalStateException("번역 결과를 만들지 못했어요. 인터넷 연결 후 다시 시도해 주세요."))
                    } else Tasks.forResult(result)
                }
            }
    }

    fun close() {
        translator?.close()
        translator = null
    }
}
