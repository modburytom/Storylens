package com.storylens.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class SpeechReader(
    context: Context,
    private val onSentenceChanged: (Int) -> Unit,
    private val onFinished: () -> Unit,
    private val onErrorMessage: (String) -> Unit = {}
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var sentences: List<String> = emptyList()
    private var index = 0

    init {
        tts = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (!ready) onErrorMessage("휴대폰의 음성 읽기 엔진을 시작할 수 없어요")
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) = continueOrFinish()
                override fun onDone(utteranceId: String?) = continueOrFinish()
            })
        }
    }

    fun speak(text: String, language: AppLanguage, rate: Float) {
        if (!ready) {
            onErrorMessage("음성 읽기가 아직 준비되지 않았어요")
            return
        }
        if (text.isBlank()) {
            onErrorMessage("먼저 번역을 완료해 주세요")
            return
        }

        stop()
        val locale = Locale.forLanguageTag(language.ttsTag)
        val support = tts?.isLanguageAvailable(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (support == TextToSpeech.LANG_MISSING_DATA || support == TextToSpeech.LANG_NOT_SUPPORTED) {
            onErrorMessage("${language.nativeName} 음성이 휴대폰에 설치되어 있지 않아요")
            return
        }

        tts?.language = locale
        tts?.setSpeechRate(rate)
        sentences = splitSentences(text)
        if (sentences.isEmpty()) return
        index = 0
        speakCurrent()
    }

    fun stop() {
        tts?.stop()
        sentences = emptyList()
        index = 0
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun speakCurrent() {
        if (index !in sentences.indices) {
            onFinished()
            return
        }
        onSentenceChanged(index)
        tts?.speak(sentences[index], TextToSpeech.QUEUE_FLUSH, null, "storylens-$index")
    }

    private fun continueOrFinish() {
        index += 1
        if (index < sentences.size) speakCurrent() else onFinished()
    }

    companion object {
        fun splitSentences(text: String): List<String> = text
            .replace("\r", "")
            .split(Regex("(?<=[.!?。！？])\\s*|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }
}
