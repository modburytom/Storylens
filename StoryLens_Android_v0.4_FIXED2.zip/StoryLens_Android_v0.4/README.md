# StoryLens Android v0.4

A private, phone-first storybook reader for **Korean, English, Chinese and Indonesian**.

## What works
- Take a photo with the Android camera or choose an image from Gallery.
- OCR on-device with Google ML Kit Text Recognition v2.
- Korean / Chinese dedicated OCR models; English / Indonesian use the Latin model.
- Translate among the four supported languages with ML Kit on-device translation.
- Edit OCR text before translating.
- Read translated text with Android TextToSpeech.
- Sentence-by-sentence highlight while reading.
- 0.8x / 1.0x / 1.2x reading speed.
- Commercial-style Material 3 UI.

## Privacy / offline notes
OCR models are bundled into the app. Translation models are downloaded to the device the first time each language pair is used; afterwards translation can run on-device. Android TTS availability depends on the speech engine and voice packs installed on the phone.

## Build
1. Install Android Studio.
2. Open this folder (`StoryLens_Android_v0.4`).
3. Let Gradle sync and install Android SDK 36 if prompted.
4. Connect an Android phone with USB debugging enabled.
5. Press Run.

Min Android: API 23 (Android 6.0).
