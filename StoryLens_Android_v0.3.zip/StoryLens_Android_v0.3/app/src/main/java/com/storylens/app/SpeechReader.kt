package com.storylens.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

enum class VoiceStyle(
    val label: String,
    val description: String,
    val pitch: Float,
    val rateMultiplier: Float
) {
    AUTO("자동 감정", "문장 분위기에 맞춰 자동으로 조절", 1.0f, 1.0f),
    WARM("따뜻하게", "포근한 동화와 가족 이야기", 1.08f, 0.92f),
    CALM("차분하게", "잠자리 동화와 설명문", 0.94f, 0.84f),
    BRIGHT("밝게", "즐겁고 신나는 장면", 1.16f, 1.05f),
    DRAMATIC("긴장감 있게", "모험과 긴장되는 장면", 0.86f, 0.90f)
}

class SpeechReader(
    context: Context,
    private val onSentenceChanged: (Int) -> Unit,
    private val onFinished: () -> Unit
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var sentences: List<String> = emptyList()
    private var index = 0
    private var speed = 1f
    private var voiceStyle = VoiceStyle.AUTO
    private var language = AppLanguage.KOREAN

    init {
        tts = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) = continueOrFinish()
                override fun onDone(utteranceId: String?) = continueOrFinish()
            })
        }
    }

    fun speak(text: String, language: AppLanguage, rate: Float, style: VoiceStyle) {
        if (!ready) return
        stop()
        speed = rate
        voiceStyle = style
        this.language = language
        sentences = splitSentences(text)
        if (sentences.isEmpty()) return
        index = 0
        tts?.language = Locale.forLanguageTag(language.ttsTag)
        speakCurrent()
    }

    fun preview(language: AppLanguage, style: VoiceStyle) {
        val sample = when (language) {
            AppLanguage.KOREAN -> "어느 날, 작은 별빛이 숲속 길을 환하게 밝혔어요."
            AppLanguage.ENGLISH -> "One day, a little starlight filled the forest path."
            AppLanguage.CHINESE -> "有一天，小小的星光照亮了森林的小路。"
            AppLanguage.INDONESIAN -> "Suatu hari, cahaya bintang kecil menerangi jalan di hutan."
        }
        speak(sample, language, 1f, style)
    }

    fun stop() {
        tts?.stop()
        sentences = emptyList()
        index = 0
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun speakCurrent() {
        if (index !in sentences.indices) {
            onFinished()
            return
        }
        onSentenceChanged(index)
        val profile = resolvedStyle(sentences[index])
        tts?.setPitch(profile.pitch)
        tts?.setSpeechRate((speed * profile.rateMultiplier).coerceIn(0.5f, 1.5f))
        tts?.speak(sentences[index], TextToSpeech.QUEUE_FLUSH, null, "storylens-$index")
    }

    private fun resolvedStyle(sentence: String): VoiceStyle {
        if (voiceStyle != VoiceStyle.AUTO) return voiceStyle
        val lower = sentence.lowercase(Locale.forLanguageTag(language.ttsTag))
        return when {
            sentence.contains("!") || sentence.contains("！") -> VoiceStyle.BRIGHT
            lower.contains(Regex("무서|어둠|위험|도망|fear|dark|danger|run|takut|gelap|bahaya|害怕|危险|黑暗")) -> VoiceStyle.DRAMATIC
            sentence.contains("?") || sentence.contains("？") -> VoiceStyle.WARM
            else -> VoiceStyle.CALM
        }
    }

    private fun continueOrFinish() {
        index += 1
        if (index < sentences.size) speakCurrent() else onFinished()
    }

    companion object {
        fun splitSentences(text: String): List<String> = text
            .replace("\r", "")
            .split(Regex("(?<=[.!?。！？])\\s*|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }
}
