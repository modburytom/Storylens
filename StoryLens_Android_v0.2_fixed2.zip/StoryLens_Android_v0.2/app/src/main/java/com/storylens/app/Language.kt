package com.storylens.app

import com.google.mlkit.nl.translate.TranslateLanguage

@Suppress("unused")
enum class AppLanguage(
    val display: String,
    val nativeName: String,
    val emoji: String,
    val mlCode: String,
    val ttsTag: String
) {
    KOREAN("Korean", "한국어", "🇰🇷", TranslateLanguage.KOREAN, "ko-KR"),
    ENGLISH("English", "English", "🇬🇧", TranslateLanguage.ENGLISH, "en-GB"),
    CHINESE("Chinese", "中文", "🇨🇳", TranslateLanguage.CHINESE, "zh-CN"),
    INDONESIAN("Indonesian", "Bahasa Indonesia", "🇮🇩", TranslateLanguage.INDONESIAN, "id-ID")
}
