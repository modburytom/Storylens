package com.storylens.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.storylens.app.ui.theme.StoryLensTheme
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var ocr: OcrEngine
    private val translator = TranslationEngine()
    private var reader: SpeechReader? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ocr = OcrEngine(this)
        setContent {
            StoryLensTheme {
                var activeSentence by remember { mutableIntStateOf(-1) }
                var reading by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) {
                    reader = SpeechReader(
                        context = this@MainActivity,
                        onSentenceChanged = { runOnUiThread { activeSentence = it; reading = true } },
                        onFinished = { runOnUiThread { activeSentence = -1; reading = false } }
                    )
                }
                StoryLensApp(
                    onOcr = { uri, lang, done, fail ->
                        ocr.recognize(uri, lang)
                            .addOnSuccessListener { done(it.text) }
                            .addOnFailureListener { fail(it.message ?: "Text recognition failed") }
                    },
                    onTranslate = { text, from, to, done, fail ->
                        translator.translate(text, from, to)
                            .addOnSuccessListener(done)
                            .addOnFailureListener { fail(it.message ?: "Translation failed") }
                    },
                    reading = reading,
                    activeSentence = activeSentence,
                    onSpeak = { text, lang, speed -> reader?.speak(text, lang, speed) },
                    onStop = { reader?.stop(); activeSentence = -1; reading = false }
                )
            }
        }
    }

    override fun onDestroy() {
        translator.close()
        reader?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoryLensApp(
    onOcr: (Uri, AppLanguage, (String) -> Unit, (String) -> Unit) -> Unit,
    onTranslate: (String, AppLanguage, AppLanguage, (String) -> Unit, (String) -> Unit) -> Unit,
    reading: Boolean,
    activeSentence: Int,
    onSpeak: (String, AppLanguage, Float) -> Unit,
    onStop: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var source by rememberSaveable { mutableStateOf(AppLanguage.KOREAN) }
    var target by rememberSaveable { mutableStateOf(AppLanguage.ENGLISH) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var sourceText by rememberSaveable { mutableStateOf("") }
    var translatedText by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("책 한 페이지를 찍어보세요") }
    var showLang by remember { mutableStateOf(false) }
    var choosingSource by remember { mutableStateOf(true) }
    var speed by rememberSaveable { mutableFloatStateOf(1f) }

    fun handleUri(uri: Uri) {
        imageUri = uri
        busy = true
        status = "글자를 읽는 중…"
        onOcr(uri, source, { text ->
            sourceText = text
            translatedText = ""
            busy = false
            status = if (text.isBlank()) "글자를 찾지 못했어요" else "원문을 확인하고 번역하세요"
        }, { error -> busy = false; status = error })
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) handleUri(uri)
    }

    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) pendingCameraUri?.let(::handleUri)
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val dir = File(context.cacheDir, "camera").apply { mkdirs() }
            val file = File(dir, "page-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            pendingCameraUri = uri
            camera.launch(uri)
        } else status = "카메라 권한이 필요해요"
    }

    fun launchCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            val dir = File(context.cacheDir, "camera").apply { mkdirs() }
            val file = File(dir, "page-${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            pendingCameraUri = uri
            camera.launch(uri)
        } else permission.launch(Manifest.permission.CAMERA)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            AnimatedVisibility(translatedText.isNotBlank()) {
                AudioBar(
                    reading = reading,
                    speed = speed,
                    onSpeed = { speed = it },
                    onPlay = { onSpeak(translatedText, target, speed) },
                    onStop = onStop
                )
            }
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            BrandHeader()
            LanguageRouteCard(
                source = source,
                target = target,
                onSource = { choosingSource = true; showLang = true },
                onTarget = { choosingSource = false; showLang = true },
                onSwap = { val old = source; source = target; target = old; sourceText = ""; translatedText = "" }
            )
            CaptureHero(
                hasImage = imageUri != null,
                status = status,
                busy = busy,
                onCamera = ::launchCamera,
                onGallery = { gallery.launch("image/*") }
            )
            if (sourceText.isNotBlank()) {
                TextCard(
                    eyebrow = "ORIGINAL · ${source.nativeName}",
                    text = sourceText,
                    editable = true,
                    onTextChange = { sourceText = it }
                )
                Button(
                    onClick = {
                        busy = true
                        status = "${target.nativeName}로 번역하는 중…"
                        onTranslate(sourceText, source, target, {
                            translatedText = it
                            busy = false
                            status = "번역 완료"
                        }, { error -> busy = false; status = error })
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("${target.nativeName}로 번역", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                }
            }
            if (translatedText.isNotBlank()) {
                ReadingCard(translatedText, target, activeSentence)
                Spacer(Modifier.height(84.dp))
            }
        }
    }

    if (showLang) {
        ModalBottomSheet(onDismissRequest = { showLang = false }) {
            LanguagePicker(
                title = if (choosingSource) "책의 언어" else "읽을 언어",
                current = if (choosingSource) source else target,
                onPick = {
                    if (choosingSource) source = it else target = it
                    showLang = false
                }
            )
        }
    }
}

@Composable
private fun BrandHeader() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) { Text("◫", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("StoryLens", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
            Text("Any book, in your language", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer) {
            Text("LOCAL", Modifier.padding(horizontal = 11.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun LanguageRouteCard(source: AppLanguage, target: AppLanguage, onSource: () -> Unit, onTarget: () -> Unit, onSwap: () -> Unit) {
    Surface(shape = RoundedCornerShape(24.dp), tonalElevation = 1.dp, shadowElevation = 2.dp) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            LanguageButton("BOOK", source, Modifier.weight(1f), onSource)
            Box(Modifier.padding(horizontal = 8.dp).size(40.dp).clip(CircleShape).clickable(onClick = onSwap).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Text("⇄", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            LanguageButton("READ", target, Modifier.weight(1f), onTarget)
        }
    }
}

@Composable
private fun LanguageButton(label: String, lang: AppLanguage, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(8.dp)) {
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(3.dp))
        Text("${lang.emoji}  ${lang.nativeName}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CaptureHero(hasImage: Boolean, status: String, busy: Boolean, onCamera: () -> Unit, onGallery: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(
            Brush.linearGradient(listOf(Color(0xFF3B3735), Color(0xFF65524A), Color(0xFFF46F52)))
        ).padding(22.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(if (hasImage) "Page captured" else "Turn a page into a story", color = Color.White, fontSize = 27.sp, lineHeight = 31.sp, fontWeight = FontWeight.ExtraBold)
            Text(status, color = Color.White.copy(alpha = 0.80f), fontSize = 14.sp)
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color.White, trackColor = Color.White.copy(alpha = .2f))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onCamera,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF332C29)),
                    shape = RoundedCornerShape(18.dp), modifier = Modifier.weight(1f).height(54.dp)
                ) { Text("📷  사진 촬영", fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = onGallery,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .6f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    shape = RoundedCornerShape(18.dp), modifier = Modifier.weight(1f).height(54.dp)
                ) { Text("▣  갤러리", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun TextCard(eyebrow: String, text: String, editable: Boolean, onTextChange: (String) -> Unit) {
    Surface(shape = RoundedCornerShape(24.dp), shadowElevation = 1.dp) {
        Column(Modifier.padding(18.dp)) {
            Text(eyebrow, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(9.dp))
            if (editable) {
                OutlinedTextField(
                    value = text, onValueChange = onTextChange,
                    modifier = Modifier.fillMaxWidth(), minLines = 4,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = .35f))
                )
            } else Text(text, fontSize = 17.sp, lineHeight = 28.sp)
        }
    }
}

@Composable
private fun ReadingCard(text: String, language: AppLanguage, active: Int) {
    val sentences = remember(text) { SpeechReader.splitSentences(text) }
    Surface(shape = RoundedCornerShape(26.dp), shadowElevation = 2.dp) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("TRANSLATION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("${language.emoji} ${language.nativeName}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
                Surface(shape = RoundedCornerShape(13.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Text("AUDIOBOOK", Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(18.dp))
            sentences.forEachIndexed { i, sentence ->
                Surface(
                    color = if (i == active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(sentence, Modifier.padding(horizontal = 10.dp, vertical = 8.dp), fontSize = 17.sp, lineHeight = 27.sp, fontWeight = if (i == active) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun AudioBar(reading: Boolean, speed: Float, onSpeed: (Float) -> Unit, onPlay: () -> Unit, onStop: () -> Unit) {
    Surface(shadowElevation = 14.dp, color = Color(0xFF24211F)) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp).clickable { if (reading) onStop() else onPlay() }) {
                Box(contentAlignment = Alignment.Center) { Text(if (reading) "■" else "▶", color = Color.White, fontSize = 18.sp) }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(if (reading) "Reading aloud" else "Ready to read", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Tap play and follow the highlighted sentence", color = Color.White.copy(alpha = .62f), fontSize = 11.sp)
            }
            Surface(shape = RoundedCornerShape(12.dp), color = Color.White.copy(alpha = .10f), modifier = Modifier.clickable {
                onSpeed(when (speed) { 0.8f -> 1f; 1f -> 1.2f; else -> 0.8f })
            }) {
                Text("${speed}×", Modifier.padding(horizontal = 12.dp, vertical = 9.dp), color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LanguagePicker(title: String, current: AppLanguage, onPick: (AppLanguage) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 30.dp)) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Text("4개 언어만 지원합니다", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        AppLanguage.entries.forEach { lang ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onPick(lang) }
                    .background(if (lang == current) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                    .padding(horizontal = 15.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(lang.emoji, fontSize = 27.sp)
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(lang.nativeName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(lang.display, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (lang == current) Text("✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(5.dp))
        }
    }
}
