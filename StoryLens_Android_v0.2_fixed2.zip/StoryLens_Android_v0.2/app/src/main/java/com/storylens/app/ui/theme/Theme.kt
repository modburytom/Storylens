package com.storylens.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StoryLensColors = lightColorScheme(
    primary = Color(0xFFF46F52),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE2D8),
    onPrimaryContainer = Color(0xFF4A1610),
    secondary = Color(0xFF50605A),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDE8E3),
    onSecondaryContainer = Color(0xFF18221F),
    background = Color(0xFFFFF8F1),
    onBackground = Color(0xFF282524),
    surface = Color(0xFFFFFCF8),
    onSurface = Color(0xFF282524),
    surfaceVariant = Color(0xFFF2E8DF),
    onSurfaceVariant = Color(0xFF625B56),
    outline = Color(0xFFB9AAA0)
)

@Composable
fun StoryLensTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = StoryLensColors,
        typography = Typography(),
        content = content
    )
}
