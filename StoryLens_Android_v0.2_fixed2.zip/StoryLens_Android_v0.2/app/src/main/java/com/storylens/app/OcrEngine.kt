package com.storylens.app

import android.content.Context
import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OcrEngine(private val context: Context) {
    fun recognize(uri: Uri, language: AppLanguage): Task<Text> {
        val image = InputImage.fromFilePath(context, uri)
        val recognizer: TextRecognizer = when (language) {
            AppLanguage.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            AppLanguage.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            AppLanguage.ENGLISH, AppLanguage.INDONESIAN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        return recognizer.process(image).addOnCompleteListener { recognizer.close() }
    }
}
