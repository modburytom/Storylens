package com.storylens.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class SpeechReader(
    context: Context,
    private val onSentenceChanged: (Int) -> Unit,
    private val onFinished: () -> Unit
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var sentences: List<String> = emptyList()
    private var index = 0
    private var speed = 1f

    init {
        tts = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) = continueOrFinish()
                override fun onDone(utteranceId: String?) = continueOrFinish()
            })
        }
    }

    fun speak(text: String, language: AppLanguage, rate: Float) {
        if (!ready) return
        stop()
        speed = rate
        sentences = splitSentences(text)
        if (sentences.isEmpty()) return
        index = 0
        tts?.language = Locale.forLanguageTag(language.ttsTag)
        tts?.setSpeechRate(speed)
        speakCurrent()
    }

    fun stop() {
        tts?.stop()
        sentences = emptyList()
        index = 0
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun speakCurrent() {
        if (index !in sentences.indices) {
            onFinished()
            return
        }
        onSentenceChanged(index)
        tts?.speak(sentences[index], TextToSpeech.QUEUE_FLUSH, null, "storylens-$index")
    }

    private fun continueOrFinish() {
        index += 1
        if (index < sentences.size) speakCurrent() else onFinished()
    }

    companion object {
        fun splitSentences(text: String): List<String> = text
            .replace("\r", "")
            .split(Regex("(?<=[.!?。！？])\\s*|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }
}
