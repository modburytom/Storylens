package com.storylens.app

import com.google.android.gms.tasks.Task
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.common.model.DownloadConditions

class TranslationEngine {
    private var translator: Translator? = null

    fun translate(text: String, from: AppLanguage, to: AppLanguage): Task<String> {
        if (from == to) {
            return com.google.android.gms.tasks.Tasks.forResult(text)
        }
        translator?.close()
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(from.mlCode)
            .setTargetLanguage(to.mlCode)
            .build()
        val newTranslator = Translation.getClient(options)
        translator = newTranslator
        val conditions = DownloadConditions.Builder().build()
        return newTranslator.downloadModelIfNeeded(conditions)
            .continueWithTask { newTranslator.translate(text) }
    }

    fun close() {
        translator?.close()
        translator = null
    }
}
